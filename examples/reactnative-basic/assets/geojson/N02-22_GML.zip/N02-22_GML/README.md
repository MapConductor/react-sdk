# Japan Railroad Section data

This data provided by National Land Information Division, National Spatial Planning and Regional Policy Bureau, MLIT of Japan.

Source: https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-N02-v3_1.html
