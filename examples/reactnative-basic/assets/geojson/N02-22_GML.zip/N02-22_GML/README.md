# Japan Railroad Section data

This data provided by National Land Information Division, National Spatial Planning and Regional Policy Bureau, MLIT of Japan.

Source: https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-N02-v3_1.html

## English names added for this sample

The original data is Japanese only. Two properties were added to every feature so
that the sample can show either language without shipping a lookup table in each
app:

| Property | Meaning |
| --- | --- |
| `N02_003` / `N02_003_en` | Railway name |
| `N02_004` / `N02_004_en` | Railway company |

Official English names are used where an operator publishes one (`JR East`,
`Tokyo Metro`, `Kintetsu Railway`). Everything else is Hepburn romanisation
without macrons - `Sobu Line`, `Tokaido Shinkansen` - matching the English
signage the operators themselves use.

`N02_001` (railway category) and `N02_002` (business category) are numeric codes
in the original data and were left untouched.
